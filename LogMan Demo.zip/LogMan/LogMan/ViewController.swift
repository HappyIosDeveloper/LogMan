//
//  ViewController.swift
//  LogMan
//
//  Created by Alfredo Uzumaki on 5/23/19.
//  Copyright © 2019 Alfredo Uzumaki. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        
        print("this one is regular print")
        
        prt(222)
        prt("hello !")
        prt("oh oh ", self)
    }
}


